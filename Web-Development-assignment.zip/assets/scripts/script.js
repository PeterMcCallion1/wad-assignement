let add_to_cart_btns = document.getElementsByClassName("btn-primary");
for(let i = 0; i < add_to_cart_btns.length; i++){
    
    add_to_cart_btns[i].addEventListener('click', addToCart)
    
}

function addToCart(event){

    btn = event.target;
    console.log(btn);
}